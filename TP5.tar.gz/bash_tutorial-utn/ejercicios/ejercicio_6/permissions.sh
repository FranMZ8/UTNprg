#!/usr/bin/env bash

CODE=A_S_D_F_S_H_J_K_L_Q_W_E_R_T_Z_U_I_Y_P

echo "el caracter 16 es:"
echo $CODE | cut -d'_' -f 5

echo "el caracter 17 es un espacio en blanco.. ' '"

