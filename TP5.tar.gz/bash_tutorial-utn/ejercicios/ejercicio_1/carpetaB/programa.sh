echo "El terecer caracter es un espacio vacio ' '."
